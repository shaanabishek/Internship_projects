marks = int(input("Enter marks: "))

if marks == 100:
    print(f"You scored {marks}. Grade S")
elif 90 <= marks < 100:
    print(f"You scored {marks}. Grade A")
elif 80 <= marks < 90:
    print(f"You scored {marks}. Grade B")
elif 70 <= marks < 80:
    print(f"You scored {marks}. Grade C")
elif 60 <= marks < 70:
    print(f"You scored {marks}. Grade D")
elif 0 <= marks < 60:
    print(f"You scored {marks}. Grade F")
else:
    print("Invalid marks.")