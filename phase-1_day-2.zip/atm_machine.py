balance = 1000
transaction_count = 0
pin = "1234"

for i in range(3):
    user_pin = input("Enter 4-digit PIN: ")

    if user_pin == pin:
        print("Login Successful")
        break
    else:
        print("Wrong PIN")

else:
    print("Account Locked")
    exit()

while True:

    print(" ATM MENU ")
    print("1. Balance")
    print("2. Deposit")
    print("3. Withdraw")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        print("Your Balance is ₹", balance)

    elif choice == "2":
        amount = float(input("Enter amount to deposit: "))

        if amount > 0:
            balance = balance + amount
            transaction_count = transaction_count + 1
            print("Deposit Successful")
        else:
            print("Invalid Amount")

    elif choice == "3":
        amount = float(input("Enter amount to withdraw: "))

        if amount > 0:
            if amount <= balance:
                balance = balance - amount
                transaction_count = transaction_count + 1
                print("Withdrawal Successful")
            else:
                print("Insufficient Balance")
        else:
            print("Invalid Amount")

    elif choice == "4":
        print("Thank You for Using ATM")
        print("Final Balance =", balance)
        print("Total Transactions =", transaction_count)
        break

    else:
        print("Invalid Choice")