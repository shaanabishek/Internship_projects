

def total_deposit(*amounts):
    return sum(amounts)

print("Total =", total_deposit(100, 200, 300))
print("Total =", total_deposit(500, 1000))