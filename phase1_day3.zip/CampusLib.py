# Author: Shaan Abishek

from datetime import datetime

books = []

while True:
    print("\n===== CAMPUS LIBRARY =====")
    print("1. Add Book")
    print("2. View Books")
    print("3. Borrow Book")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        title = input("Enter book title: ")
        author = input("Enter author name: ")

        books.append({"title": title, "author": author})
        print("Book Added Successfully!")

    elif choice == "2":
        if len(books) == 0:
            print("No books available.")
        else:
            print("\nAvailable Books")
            for i, book in enumerate(books, start=1):
                print(f"{i}. {book['title']} | {book['author']}")

    elif choice == "3":
        title = input("Enter book title to borrow: ")

        found = False

        for book in books:
            if book["title"].lower() == title.lower():
                books.remove(book)

                with open("borrow_log.txt", "a") as file:
                    file.write(f"{datetime.now()} : {title} borrowed\n")

                print("Book Borrowed Successfully!")
                found = True
                break

        if not found:
            print("Book not found.")

    elif choice == "4":
        print("Thank you for using Campus Library.")
        break

    else:
        print("Invalid choice.")