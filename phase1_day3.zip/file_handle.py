
with open("notes.txt", "w") as file:
    file.write("Hello Python!\n")
    file.write("Created by Shaan Abishek\n")

with open("notes.txt", "r") as file:
    print(file.read())