
def build_receipt(**details):
    receipt = ""
    for key, value in details.items():
        receipt += f"{key}: {value}\n"
    return receipt
# Example 1
print(build_receipt(
    name="Shaan Abishek",
    age= 20,
    amount=250,
    type="Food",
    payment="Cash"
))

