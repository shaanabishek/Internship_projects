balance = 5000

def show_balance():
    print("Balance:", balance)

def deposit(amount):
    global balance
    balance += amount

show_balance()
deposit(1000)
print("Updated Balance:", balance)